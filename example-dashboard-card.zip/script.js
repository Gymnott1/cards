// script.js (Mini Dashboard Card)
document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const timeEl = document.getElementById('current-time');
    const dateEl = document.getElementById('current-date');
    const cpuLoadEl = document.getElementById('cpu-load');
    const cpuBarEl = document.getElementById('cpu-bar');
    const memoryUsageEl = document.getElementById('memory-usage');
    const memoryBarEl = document.getElementById('memory-bar');
    const statusIndicatorEl = document.getElementById('status-indicator');
    const closeBtn = document.getElementById('close-card');

    let timeIntervalId = null;
    let statsIntervalId = null;

    // --- Update Functions ---
    function updateTime() {
        if (!timeEl) return;
        const now = new Date();
        timeEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    }

    function updateDate() {
        if (!dateEl) return;
        const now = new Date();
        dateEl.textContent = now.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    }

    function updateStats() {
        // Simulate fluctuating CPU load (e.g., 5% to 65%)
        const cpuLoad = Math.floor(5 + Math.random() * 60);
        if (cpuLoadEl) cpuLoadEl.textContent = `${cpuLoad}%`;
        if (cpuBarEl) cpuBarEl.style.width = `${cpuLoad}%`;

        // Simulate fluctuating Memory usage (e.g., 20% to 80%)
        const memUsage = Math.floor(20 + Math.random() * 60);
        if (memoryUsageEl) memoryUsageEl.textContent = `${memUsage}%`;
        if (memoryBarEl) memoryBarEl.style.width = `${memUsage}%`;

        // Could update status indicator based on thresholds here too
        // e.g., if (cpuLoad > 80) { updateStatus('High Load', 'warning'); }
    }

    function updateStatus(text, type = 'nominal') {
         if (!statusIndicatorEl) return;
         statusIndicatorEl.textContent = `● ${text}`;
         statusIndicatorEl.className = `status ${type}`; // Reset classes and add new type
    }


    // --- Event Listeners ---
    if (closeBtn && window.theCardAPI?.requestClose) {
        closeBtn.addEventListener('click', () => window.theCardAPI.requestClose());
    } else {
         console.warn("API 'requestClose' not found.");
         if(closeBtn) closeBtn.style.display = 'none'; // Hide button if API unusable
    }

    // --- Initialization ---
    function initialize() {
        console.log("Dashboard Card script initializing...");
        updateTime(); // Initial time set
        updateDate(); // Initial date set
        updateStats(); // Initial stats set
        updateStatus("Nominal", "nominal"); // Initial status

        // Start intervals
        timeIntervalId = setInterval(updateTime, 1000); // Update time every second
        statsIntervalId = setInterval(updateStats, 2500); // Update stats every 2.5 seconds

         console.log("Dashboard Card Initialized.");
    }

    // --- Cleanup (Important for potential future hot-reloading or complex scenarios) ---
    // Although closing the BrowserView usually stops JS, this is good practice
    function cleanup() {
        console.log("Dashboard Card cleaning up intervals.");
        if (timeIntervalId) clearInterval(timeIntervalId);
        if (statsIntervalId) clearInterval(statsIntervalId);
        timeIntervalId = null;
        statsIntervalId = null;
    }

    // Note: Electron doesn't have a standard reliable 'unload' event for BrowserView content.
    // Relying on the view being destroyed is the typical approach.
    // We could potentially use an IPC message from main on 'closed', but that's more complex.

    // Run Initialization
    initialize();

});