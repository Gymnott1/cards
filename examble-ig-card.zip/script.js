// Wait for DOM to fully load
document.addEventListener('DOMContentLoaded', () => {
    // Initialize the app
    initApp();
});

function initApp() {
    // Initialize like functionality
    initLikes();
    
    // Initialize comment functionality
    initComments();
    
    // Initialize navigation
    initNavigation();
    
    // Initialize story interactions
    initStories();
    
    // Add post double-tap to like functionality
    initDoubleTapLike();
    
    // Make the app responsive
    initResponsive();
    
    // Add animation effects
    initAnimations();
}

// Like functionality
function initLikes() {
    const heartIcons = document.querySelectorAll('.fa-heart');
    
    heartIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            // Toggle between filled and regular heart
            if (this.classList.contains('fa-regular')) {
                this.classList.remove('fa-regular');
                this.classList.add('fa-solid', 'liked');
                
                // Update like count
                const likeContainer = this.closest('.post').querySelector('.post-likes span');
                const currentLikes = parseLikeCount(likeContainer.textContent);
                likeContainer.textContent = `${currentLikes + 1} likes`;
            } else {
                this.classList.remove('fa-solid', 'liked');
                this.classList.add('fa-regular');
                
                // Update like count
                const likeContainer = this.closest('.post').querySelector('.post-likes span');
                const currentLikes = parseLikeCount(likeContainer.textContent);
                likeContainer.textContent = `${currentLikes - 1} likes`;
            }
        });
    });
}

// Parse like count from string (e.g. "1,234 likes" -> 1234)
function parseLikeCount(likeText) {
    return parseInt(likeText.replace(/,/g, ''));
}

// Comment functionality
function initComments() {
    const commentForms = document.querySelectorAll('.add-comment');
    
    commentForms.forEach(form => {
        const input = form.querySelector('input');
        const button = form.querySelector('button');
        
        // Disable post button when input is empty
        input.addEventListener('input', () => {
            button.style.opacity = input.value.trim() ? '1' : '0.5';
        });
        
        // Handle comment submission
        button.addEventListener('click', () => {
            const commentText = input.value.trim();
            if (commentText) {
                addComment(form, commentText);
                input.value = '';
                button.style.opacity = '0.5';
            }
        });
        
        // Submit on Enter key
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const commentText = input.value.trim();
                if (commentText) {
                    addComment(form, commentText);
                    input.value = '';
                    button.style.opacity = '0.5';
                }
            }
        });
    });
}

// Add a new comment to the post
function addComment(form, commentText) {
    const post = form.closest('.post');
    const commentsSection = post.querySelector('.post-comments');
    const newComment = document.createElement('div');
    newComment.className = 'comment';
    
    // Get username from local storage or use default
    const username = localStorage.getItem('username') || 'you';
    
    newComment.innerHTML = `
        <span class="username">${username}</span>
        <span class="comment-text">${commentText}</span>
    `;
    
    // Insert new comment before the add comment form
    commentsSection.appendChild(newComment);
    
    // Update comment count in "View all X comments"
    const viewCommentsEl = commentsSection.querySelector('.view-comments');
    if (viewCommentsEl) {
        const currentText = viewCommentsEl.textContent;
        const commentCount = parseInt(currentText.match(/\d+/)[0]) + 1;
        viewCommentsEl.textContent = `View all ${commentCount} comments`;
    }
}

// Navigation functionality
function initNavigation() {
    const navIcons = document.querySelectorAll('.bottom-nav i');
    
    navIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            // Remove active class from all icons
            navIcons.forEach(i => i.classList.remove('active'));
            
            // Add active class to clicked icon
            this.classList.add('active');
            
            // Show alert for navigation (in a real app, this would navigate to a different page)
            const navName = this.className.split(' ')[1].replace('fa-', '');
            showNotification(`Navigating to ${navName}...`);
        });
    });
}

// Story interaction
function initStories() {
    const stories = document.querySelectorAll('.story');
    
    stories.forEach(story => {
        story.addEventListener('click', function() {
            const username = this.querySelector('span').textContent;
            showNotification(`Viewing ${username}'s story...`);
        });
    });
    
    // Add your story functionality
    const yourStory = document.querySelector('.your-story');
    if (yourStory) {
        yourStory.addEventListener('click', () => {
            showNotification('Create a new story...');
        });
    }
}

// Double-tap to like functionality
function initDoubleTapLike() {
    const postImages = document.querySelectorAll('.post-image');
    
    postImages.forEach(image => {
        let lastTap = 0;
        
        image.addEventListener('click', function() {
            const currentTime = new Date().getTime();
            const tapLength = currentTime - lastTap;
            
            // Double tap detected
            if (tapLength < 300 && tapLength > 0) {
                const post = this.closest('.post');
                const heartIcon = post.querySelector('.fa-heart');
                
                // Like the post if not already liked
                if (heartIcon.classList.contains('fa-regular')) {
                    heartIcon.click();
                    
                    // Show heart animation
                    showHeartAnimation(this);
                }
            }
            
            lastTap = currentTime;
        });
    });
}

// Show heart animation on double tap
function showHeartAnimation(imageContainer) {
    const heart = document.createElement('i');
    heart.className = 'fa-solid fa-heart double-tap-heart';
    heart.style.cssText = `
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        font-size: 80px;
        opacity: 0;
        text-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        pointer-events: none;
        animation: heart-animation 1s ease-out forwards;
    `;
    
    // Make the image container position relative if not already
    if (getComputedStyle(imageContainer).position === 'static') {
        imageContainer.style.position = 'relative';
    }
    
    imageContainer.appendChild(heart);
    
    // Remove heart element after animation
    setTimeout(() => {
        heart.remove();
    }, 1000);
}

// Notification helper
function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        bottom: 70px;
        left: 50%;
        transform: translateX(-50%);
        background-color: #262626;
        color: white;
        padding: 10px 20px;
        border-radius: 20px;
        font-size: 14px;
        z-index: 1000;
        opacity: 0;
        transition: opacity 0.3s;
    `;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.style.opacity = '1';
    }, 10);
    
    // Remove after delay
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 2000);
}

// Handle responsive design
function initResponsive() {
    const appContainer = document.querySelector('.app-container');
    
    function adjustHeight() {
        const windowHeight = window.innerHeight;
        appContainer.style.minHeight = `${windowHeight}px`;
    }
    
    // Initial adjustment
    adjustHeight();
    
    // Adjust on resize
    window.addEventListener('resize', adjustHeight);
}

// Animation effects
function initAnimations() {
    // Add style for animations
    const styleSheet = document.createElement('style');
    styleSheet.type = 'text/css';
    styleSheet.innerHTML = `
        @keyframes heart-animation {
            0% { opacity: 0; transform: translate(-50%, -50%) scale(0.5); }
            15% { opacity: 1; }
            30% { opacity: 1; transform: translate(-50%, -50%) scale(1.2); }
            100% { opacity: 0; transform: translate(-50%, -50%) scale(1); }
        }
        
        .bounce {
            animation: bounce 0.3s ease;
        }
        
        @keyframes bounce {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
    `;
    document.head.appendChild(styleSheet);
    
    // Add click bounce effect to buttons
    const buttons = document.querySelectorAll('button, .fa-solid, .fa-regular');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            this.classList.add('bounce');
            setTimeout(() => {
                this.classList.remove('bounce');
            }, 300);
        });
    });
}