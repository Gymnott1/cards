// script.js (Wedding Invitation)
document.addEventListener('DOMContentLoaded', () => {
    const likeButton = document.getElementById('like-button');
    const likeCountSpan = document.getElementById('like-count');
    const closeBtn = document.getElementById('close-card');

    let isLiked = false;
    let likeCount = Math.floor(Math.random() * 20); // Fake initial likes

    function updateLikeUI() {
        if (!likeButton || !likeCountSpan) return;
        likeCountSpan.textContent = likeCount;
        likeButton.classList.toggle('liked', isLiked);
        likeButton.textContent = `${isLiked ? '❤️ Liked' : '🤍 Like'} ( ${likeCount} )`;
    }

    function handleLike() {
         // In a real app, this would send a request to a backend
         console.log("Like button clicked. Current state:", isLiked);
         if (isLiked) {
             likeCount--;
             isLiked = false;
             // Send 'unlike' request to backend
             console.log("TODO: Send 'unlike' request to backend");
         } else {
             likeCount++;
             isLiked = true;
             // Send 'like' request to backend
             console.log("TODO: Send 'like' request to backend");
         }
         updateLikeUI();

          // Show a temporary notification (using platform API if available)
          if (window.theCardAPI?.showPlatformNotification) {
              window.theCardAPI.showPlatformNotification("Wedding Invite", isLiked ? "You liked the invitation!" : "Like removed.");
          }
    }

    if (likeButton) {
        likeButton.addEventListener('click', handleLike);
    }

    if (closeBtn && window.theCardAPI?.requestClose) {
        closeBtn.onclick = () => { window.theCardAPI.requestClose(); };
    } else { if(closeBtn) closeBtn.disabled = true; }

    // Initial state
    updateLikeUI();
    console.log("Wedding Invitation Card script loaded.");
});