// script.js (Echo Chat Card - Updated for Window Drag)
document.addEventListener('DOMContentLoaded', () => {
    // REMOVED chatContainer and dragHandle references for JS drag
    const messagesArea = document.getElementById('messages-area');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const closeButton = document.getElementById('close-button'); // Keep close button ref

    // --- REMOVED Drag Logic ---
    // (Removed isDragging, initialX, initialY, xOffset, yOffset)
    // (Removed getPointerCoords, dragStart, dragEnd, drag, setTranslate functions)
    // (Removed event listeners for dragHandle)
    // --- End REMOVED Drag Logic ---


    // --- Chat Logic (Remains the same) ---
    function addMessageToUI(text, type) {
        if (!messagesArea || !text) return;
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', type);
        const span = document.createElement('span');
        span.textContent = text;
        messageElement.appendChild(span);
        messagesArea.appendChild(messageElement);
        messagesArea.scrollTop = messagesArea.scrollHeight;
    }

    function handleSendMessage() {
        if (!messageInput || !sendButton) return;
        const messageText = messageInput.value.trim();
        if (messageText) {
            addMessageToUI(messageText, 'sent');
            messageInput.value = '';
            sendButton.disabled = true;
            setTimeout(() => {
                addMessageToUI(messageText, 'received');
                if (sendButton) sendButton.disabled = false;
            }, 800 + Math.random() * 500);
        }
    }

    // --- Event Listeners (Keep non-drag listeners) ---
    if (sendButton) sendButton.addEventListener('click', handleSendMessage);
    if (messageInput) messageInput.addEventListener('keypress', (e) => {
         if (e.key === 'Enter' && !sendButton?.disabled) { e.preventDefault(); handleSendMessage(); }
     });

    // Close button still uses preload API
    if (closeButton && window.theCardAPI?.requestClose) {
        closeButton.onclick = () => window.theCardAPI.requestClose();
    } else { console.warn("API 'requestClose' not found."); if(closeButton) closeButton.style.display = 'none'; }

    console.log("Echo Chat Card script loaded (Window Drag version).");
    // Add initial system message if desired
    if (!messagesArea.querySelector('.message')) { // Check if empty
         addMessageToUI("Type a message to start echo!", "system received"); // Use system style if defined
    }

});