// script.js (Echo Chat Card)
document.addEventListener('DOMContentLoaded', () => {
    const chatContainer = document.getElementById('chat-card-container'); // The element to drag
    const dragHandle = document.getElementById('card-header-drag-handle');
    const messagesArea = document.getElementById('messages-area');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const closeButton = document.getElementById('close-button');

    // --- Drag Logic ---
    let isDragging = false;
    let initialX, initialY;
    let xOffset = 0, yOffset = 0;

    if (dragHandle && chatContainer) {
        const getPointerCoords = e => e.type.startsWith('touch') ? e.touches[0] : e;

        const dragStart = (e) => {
            const pointer = getPointerCoords(e);
            // Get current transform values if they exist
            const style = window.getComputedStyle(chatContainer);
            const matrix = new DOMMatrixReadOnly(style.transform);
            xOffset = matrix.m41; // Current translateX
            yOffset = matrix.m42; // Current translateY

            initialX = pointer.clientX - xOffset;
            initialY = pointer.clientY - yOffset;
            isDragging = true;
            chatContainer.style.cursor = 'grabbing'; // Change cursor while dragging
            e.stopPropagation(); // Prevent interference if inside another draggable
        };

        const dragEnd = () => {
            if (isDragging) {
                isDragging = false;
                chatContainer.style.cursor = 'default'; // Reset cursor
                // Optional: Snap to edges or save position? Not for MVP.
            }
        };

        const drag = (e) => {
            if (!isDragging) return;
            e.preventDefault(); // Prevent text selection/scrolling
            const pointer = getPointerCoords(e);
            const currentX = pointer.clientX - initialX;
            const currentY = pointer.clientY - initialY;
            xOffset = currentX; // Update offset for next potential drag start
            yOffset = currentY;
            chatContainer.style.transform = `translate3d(${currentX}px, ${currentY}px, 0)`;
        };

        dragHandle.addEventListener('mousedown', dragStart);
        document.addEventListener('mouseup', dragEnd);
        document.addEventListener('mousemove', drag);

        dragHandle.addEventListener('touchstart', dragStart, { passive: true }); // Allow scroll potentially
        document.addEventListener('touchend', dragEnd);
        document.addEventListener('touchmove', drag, { passive: false }); // Need active to prevent scroll
    } else {
        console.warn("Draggable elements not found.");
    }

    // --- Chat Logic ---
    function addMessageToUI(text, type) {
        if (!messagesArea || !text) return;

        const messageElement = document.createElement('div');
        messageElement.classList.add('message', type);

        const span = document.createElement('span');
        span.textContent = text; // Use textContent for security
        messageElement.appendChild(span);

        messagesArea.appendChild(messageElement);

        // Scroll to bottom
        messagesArea.scrollTop = messagesArea.scrollHeight;
    }

    function handleSendMessage() {
        if (!messageInput || !sendButton) return;
        const messageText = messageInput.value.trim();

        if (messageText) {
            // 1. Display sent message
            addMessageToUI(messageText, 'sent');
            messageInput.value = ''; // Clear input

            // 2. Simulate receiving echo after delay
            sendButton.disabled = true; // Prevent rapid sending
            setTimeout(() => {
                addMessageToUI(messageText, 'received'); // Echo the same message
                if (sendButton) sendButton.disabled = false; // Re-enable send
            }, 800 + Math.random() * 500); // Simulate network delay (0.8-1.3s)
        }
    }

    // --- Event Listeners ---
    if (sendButton) sendButton.addEventListener('click', handleSendMessage);
    if (messageInput) messageInput.addEventListener('keypress', (e) => {
         if (e.key === 'Enter' && !sendButton?.disabled) {
             e.preventDefault();
             handleSendMessage();
         }
     });

    if (closeButton && window.theCardAPI?.requestClose) {
        closeButton.onclick = () => window.theCardAPI.requestClose();
    } else { console.warn("API 'requestClose' not found."); if(closeButton) closeButton.style.display = 'none'; }

    console.log("Echo Chat Card script loaded.");

});