// script.js (Digital Credit Card)
document.addEventListener('DOMContentLoaded', () => {
    const creditCard = document.getElementById('credit-card');
    const flipButton = document.getElementById('flip-button');
    const closeButton = document.getElementById('close-button');
    const simulateChargeButton = document.getElementById('simulate-charge-button');

    // Card Data Elements
    const cardNumberEl = document.getElementById('card-number');
    const cardHolderNameEl = document.getElementById('card-holder-name');
    const cardExpiryEl = document.getElementById('card-expiry');
    const cardCvvEl = document.getElementById('card-cvv');
    const availableBalanceEl = document.getElementById('available-balance');
    const currentBalanceEl = document.getElementById('current-balance');

    // --- State & Simulated Data ---
    let cardData = {
        number: '4012 8888 8888 1234', // Keep full number internally
        maskedNumber: '**** **** **** 1234',
        holder: 'YOUR NAME',
        expiry: '12/28',
        cvv: '123', // Keep internal only
        availableBalance: 5000.00,
        currentBalance: 255.50,
        limit: 5255.50
    };
    let isFrontVisible = true;
    const chargeAmount = 25.00;

    // --- Functions ---
    function formatCurrency(amount) {
        return `$${amount.toFixed(2)}`;
    }

    function updateUI() {
        if (cardNumberEl) cardNumberEl.textContent = cardData.maskedNumber;
        if (cardHolderNameEl) cardHolderNameEl.textContent = cardData.holder;
        if (cardExpiryEl) cardExpiryEl.textContent = cardData.expiry;
        if (cardCvvEl) cardCvvEl.textContent = '***'; // Never display full CVV

        if (availableBalanceEl) availableBalanceEl.textContent = formatCurrency(cardData.availableBalance);
        if (currentBalanceEl) currentBalanceEl.textContent = formatCurrency(cardData.currentBalance);

        if (creditCard) creditCard.classList.toggle('flipped', !isFrontVisible);
    }

    function flipCard() {
        isFrontVisible = !isFrontVisible;
        console.log(`Card flipped. Front visible: ${isFrontVisible}`);
        updateUI();
    }

    function simulateCharge() {
        if (cardData.availableBalance >= chargeAmount) {
            cardData.availableBalance -= chargeAmount;
            cardData.currentBalance += chargeAmount;
            console.log(`Simulated charge of ${formatCurrency(chargeAmount)}`);
            updateUI();
             if (window.theCardAPI?.showPlatformNotification) {
                window.theCardAPI.showPlatformNotification("Transaction", `Simulated charge: ${formatCurrency(chargeAmount)}`);
             }
        } else {
             console.log("Simulated charge failed: Insufficient available balance.");
             if (window.theCardAPI?.showPlatformNotification) {
                 window.theCardAPI.showPlatformNotification("Transaction Failed", `Insufficient available balance for ${formatCurrency(chargeAmount)} charge.`);
             } else {
                  alert("Insufficient available balance."); // Fallback
             }
        }
    }

    // --- Event Listeners ---
    if (flipButton) flipButton.addEventListener('click', flipCard);
    if (simulateChargeButton) simulateChargeButton.addEventListener('click', simulateCharge);

    if (closeButton && window.theCardAPI?.requestClose) {
        closeButton.onclick = () => window.theCardAPI.requestClose();
    } else { console.warn("API 'requestClose' not found."); if(closeButton) closeButton.disabled = true; }

    // --- Initial Load ---
    updateUI();
    console.log("Digital Credit Card script loaded.");
});