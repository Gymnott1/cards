// script.js (Snake Game Card)
document.addEventListener('DOMContentLoaded', () => {
    // --- API Check ---
    const platformAPI = window.theCardAPI;
    if (!platformAPI?.requestClose) {
        console.warn("Platform API 'requestClose' not available.");
        // Optionally disable close button or hide it
        const closeBtn = document.getElementById('close-button');
        if (closeBtn) closeBtn.style.display = 'none';
    }

    // --- DOM Elements ---
    const canvas = document.getElementById('game-canvas');
    const ctx = canvas.getContext('2d');
    const scoreEl = document.getElementById('score');
    const gameOverOverlay = document.getElementById('game-over-overlay');
    const startOverlay = document.getElementById('start-overlay');
    const startButton = document.getElementById('start-button-overlay');
    const resetButton = document.getElementById('reset-button-overlay');
    const closeButton = document.getElementById('close-button'); // Header close btn

    // --- Game Constants ---
    const TILE_SIZE = 15; // Size of each grid square/snake segment
    const GRID_WIDTH = canvas.width / TILE_SIZE;
    const GRID_HEIGHT = canvas.height / TILE_SIZE;
    const INITIAL_SPEED_MS = 150; // Lower is faster

    // --- Game State ---
    let snake;
    let food;
    let dx; // Direction x (1, -1, or 0)
    let dy; // Direction y (1, -1, or 0)
    let changingDirection; // Lock to prevent multiple direction changes per tick
    let score;
    let gameLoopIntervalId;
    let currentSpeedMs;
    let isGameOver;
    let isPaused; // For start overlay

    // --- Initialization ---
    function initGame() {
        console.log("Initializing game state...");
        snake = [ // Start snake in the middle
            { x: Math.floor(GRID_WIDTH / 2), y: Math.floor(GRID_HEIGHT / 2) },
            { x: Math.floor(GRID_WIDTH / 2) - 1, y: Math.floor(GRID_HEIGHT / 2) },
            { x: Math.floor(GRID_WIDTH / 2) - 2, y: Math.floor(GRID_HEIGHT / 2) },
        ];
        food = { x: -1, y: -1 }; // Invalid initial position
        generateFood();
        dx = TILE_SIZE; // Start moving right
        dy = 0;
        changingDirection = false;
        score = 0;
        scoreEl.textContent = score;
        currentSpeedMs = INITIAL_SPEED_MS;
        isGameOver = false;
        isPaused = true; // Start paused

        gameOverOverlay.classList.remove('show');
        startOverlay.classList.add('show'); // Show start overlay

        clearCanvas();
        drawSnake();
        drawFood();
    }

    // --- Game Loop ---
    function gameLoop() {
         if (isGameOver || isPaused) return;

         changingDirection = false; // Allow direction change for next tick
         clearCanvas();
         drawFood();
         moveSnake();
         drawSnake(); // Draw after moving
    }

    function startGame() {
         if (!isPaused) return; // Already running
         console.log("Starting game loop...");
         isPaused = false;
         startOverlay.classList.remove('show');
         if (gameLoopIntervalId) clearInterval(gameLoopIntervalId); // Clear previous interval if any
         gameLoopIntervalId = setInterval(gameLoop, currentSpeedMs);
    }

    function resetGame() {
        console.log("Resetting game...");
         if (gameLoopIntervalId) clearInterval(gameLoopIntervalId);
         gameLoopIntervalId = null;
         initGame(); // Re-initialize everything
    }

    function endGame() {
        console.log("Game Over!");
        isGameOver = true;
        if (gameLoopIntervalId) clearInterval(gameLoopIntervalId);
        gameLoopIntervalId = null;
        gameOverOverlay.classList.add('show');
    }

    // --- Drawing ---
    function clearCanvas() {
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--game-bg').trim() || '#0d1a20'; // Use CSS var
        ctx.fillRect(0, 0, canvas.width, canvas.height);
         // Optional: Draw grid lines
        // ctx.strokeStyle = '#22303f';
        // for (let x = 0; x < canvas.width; x += TILE_SIZE) ctx.strokeRect(x, 0, TILE_SIZE, canvas.height);
        // for (let y = 0; y < canvas.height; y += TILE_SIZE) ctx.strokeRect(0, y, canvas.width, TILE_SIZE);
    }

    function drawRect(x, y, color) {
        ctx.fillStyle = color;
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
         ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--bg-color').trim() || '#1a2a33'; // Border color slightly lighter
         ctx.strokeRect(x, y, TILE_SIZE, TILE_SIZE);
    }

    function drawSnake() {
        const snakeColor = getComputedStyle(document.documentElement).getPropertyValue('--snake-color').trim() || '#00e676';
        snake.forEach((segment, index) => {
            // Make head slightly different? (Optional)
            // const color = index === 0 ? '#00ff88' : snakeColor;
            drawRect(segment.x * TILE_SIZE, segment.y * TILE_SIZE, snakeColor);
        });
    }

    function drawFood() {
        const foodColor = getComputedStyle(document.documentElement).getPropertyValue('--food-color').trim() || '#ff5252';
        drawRect(food.x * TILE_SIZE, food.y * TILE_SIZE, foodColor);
    }

    // --- Movement & Logic ---
    function moveSnake() {
        // Calculate new head position
        const head = { x: snake[0].x + dx / TILE_SIZE, y: snake[0].y + dy / TILE_SIZE };

        // Check for collisions BEFORE adding head
        if (checkCollision(head)) {
            endGame();
            return;
        }

        // Add new head
        snake.unshift(head);

        // Check if food eaten
        if (head.x === food.x && head.y === food.y) {
            score += 10;
            scoreEl.textContent = score;
            // Increase speed slightly (optional)
            // currentSpeedMs = Math.max(50, currentSpeedMs - 5); // Speed up, minimum 50ms
            // clearInterval(gameLoopIntervalId);
            // gameLoopIntervalId = setInterval(gameLoop, currentSpeedMs);
            generateFood(); // Don't remove tail, generate new food
        } else {
            // Remove tail segment
            snake.pop();
        }
    }

    function checkCollision(head) {
        // Wall collision
        if (head.x < 0 || head.x >= GRID_WIDTH || head.y < 0 || head.y >= GRID_HEIGHT) {
            console.log("Collision: Wall");
            return true;
        }
        // Self collision (check if head hits any part of the body)
        // Start check from index 1 (ignore hitting the head itself immediately)
        for (let i = 1; i < snake.length; i++) {
            if (head.x === snake[i].x && head.y === snake[i].y) {
                 console.log("Collision: Self");
                 return true;
            }
        }
        return false;
    }

    function generateFood() {
        let newFoodX, newFoodY;
        do {
            newFoodX = Math.floor(Math.random() * GRID_WIDTH);
            newFoodY = Math.floor(Math.random() * GRID_HEIGHT);
        } while (isFoodOnSnake(newFoodX, newFoodY)); // Keep trying until it's not on the snake

        food = { x: newFoodX, y: newFoodY };
        // console.log("New food at:", food); // Debug
    }

     function isFoodOnSnake(foodX, foodY) {
         return snake.some(segment => segment.x === foodX && segment.y === foodY);
     }


    // --- Input Handling ---
    function changeDirection(event) {
         if (changingDirection || isPaused || isGameOver) return; // Prevent multiple changes per tick or when game not active

        const LEFT_KEY = 37; const ArrowLeft = "ArrowLeft";
        const RIGHT_KEY = 39; const ArrowRight = "ArrowRight";
        const UP_KEY = 38; const ArrowUp = "ArrowUp";
        const DOWN_KEY = 40; const ArrowDown = "ArrowDown";

        const keyPressed = event.key || event.keyCode; // Use event.key preferred

         // Prevent snake from reversing onto itself
        const goingUp = dy === -TILE_SIZE;
        const goingDown = dy === TILE_SIZE;
        const goingLeft = dx === -TILE_SIZE;
        const goingRight = dx === TILE_SIZE;

        let newDx = dx;
        let newDy = dy;

        if ((keyPressed === LEFT_KEY || keyPressed === ArrowLeft) && !goingRight) {
            newDx = -TILE_SIZE; newDy = 0;
        } else if ((keyPressed === UP_KEY || keyPressed === ArrowUp) && !goingDown) {
            newDx = 0; newDy = -TILE_SIZE;
        } else if ((keyPressed === RIGHT_KEY || keyPressed === ArrowRight) && !goingLeft) {
            newDx = TILE_SIZE; newDy = 0;
        } else if ((keyPressed === DOWN_KEY || keyPressed === ArrowDown) && !goingUp) {
            newDx = 0; newDy = TILE_SIZE;
        }

         // Only update if direction actually changed
         if (newDx !== dx || newDy !== dy) {
            dx = newDx;
            dy = newDy;
            changingDirection = true; // Lock direction change for this tick
         }
    }

    // --- Event Listeners ---
    document.addEventListener('keydown', changeDirection);
    startButton.addEventListener('click', startGame);
    resetButton.addEventListener('click', resetGame);
    if (closeButton && platformAPI?.requestClose) {
        closeButton.addEventListener('click', () => platformAPI.requestClose());
    }

    // --- Initial Setup ---
    initGame();

}); // End DOMContentLoaded